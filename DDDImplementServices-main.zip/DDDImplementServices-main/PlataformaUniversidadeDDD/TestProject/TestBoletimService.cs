using DDD.Domain.Service;
using DDD.Infra.SQLServer.Interfaces;

namespace TestProject
{
    public class TestBoletimService
    {
        [Fact]
        public void ConsegueGerarBoletim()
        {


        }
    }
}
